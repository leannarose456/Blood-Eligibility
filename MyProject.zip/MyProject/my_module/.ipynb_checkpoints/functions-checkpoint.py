"""A collection of function for doing my project."""

def my_func():
    pass

def my_other_func():
    pass
